from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd

from External_Models.alignment.hungarian_matcher import (
    average_matched_similarity,
    hungarian_match_clusters,
)
from External_Models.alignment.similarity_metrics import (
    cluster_jaccard_matrix_from_labels,
)


def extract_common_paper_ids(
    features_df_a: pd.DataFrame,
    features_df_b: pd.DataFrame,
) -> List[str]:
    """
    Extract sorted list of common paper IDs between two windows.
    """
    ids_a = set(features_df_a["paper_id"].astype(str))
    ids_b = set(features_df_b["paper_id"].astype(str))
    return sorted(ids_a & ids_b)


def build_label_maps(
    features_df: pd.DataFrame,
    labels: Sequence[int],
) -> Dict[str, int]:
    """
    Build mapping: paper_id -> cluster label.
    """
    paper_ids = features_df["paper_id"].astype(str).tolist()

    if len(paper_ids) != len(labels):
        raise ValueError(
            f"Length mismatch: got {len(paper_ids)} paper IDs and {len(labels)} labels."
        )

    return {paper_id: int(label) for paper_id, label in zip(paper_ids, labels)}


def compare_temporal_windows(
    features_df_a: pd.DataFrame,
    labels_a: Sequence[int],
    features_df_b: pd.DataFrame,
    labels_b: Sequence[int],
) -> Dict[str, object]:
    """
    Compare clustering structure between two temporal windows using:
    - common paper IDs
    - Jaccard similarity matrix
    - Hungarian matching

    Returns
    -------
    Dict[str, object]
        Contains:
        - common_paper_ids
        - num_common_papers
        - similarity_matrix
        - cluster_ids_a
        - cluster_ids_b
        - matches_dict
        - matches_list
        - average_matched_similarity
    """
    common_paper_ids = extract_common_paper_ids(features_df_a, features_df_b)

    if len(common_paper_ids) == 0:
        return {
            "common_paper_ids": [],
            "num_common_papers": 0,
            "similarity_matrix": np.array([]),
            "cluster_ids_a": [],
            "cluster_ids_b": [],
            "matches_dict": {},
            "matches_list": [],
            "average_matched_similarity": 0.0,
        }

    label_map_a = build_label_maps(features_df_a, labels_a)
    label_map_b = build_label_maps(features_df_b, labels_b)

    common_labels_a = [label_map_a[paper_id] for paper_id in common_paper_ids]
    common_labels_b = [label_map_b[paper_id] for paper_id in common_paper_ids]

    similarity_matrix, cluster_ids_a, cluster_ids_b = cluster_jaccard_matrix_from_labels(
        node_ids_a=common_paper_ids,
        labels_a=common_labels_a,
        node_ids_b=common_paper_ids,
        labels_b=common_labels_b,
    )

    matches_dict, matches_list = hungarian_match_clusters(
        similarity_matrix=similarity_matrix,
        cluster_ids_a=cluster_ids_a,
        cluster_ids_b=cluster_ids_b,
    )

    avg_similarity = average_matched_similarity(matches_list)

    return {
        "common_paper_ids": common_paper_ids,
        "num_common_papers": int(len(common_paper_ids)),
        "similarity_matrix": similarity_matrix,
        "cluster_ids_a": cluster_ids_a,
        "cluster_ids_b": cluster_ids_b,
        "matches_dict": matches_dict,
        "matches_list": matches_list,
        "average_matched_similarity": float(avg_similarity),
    }