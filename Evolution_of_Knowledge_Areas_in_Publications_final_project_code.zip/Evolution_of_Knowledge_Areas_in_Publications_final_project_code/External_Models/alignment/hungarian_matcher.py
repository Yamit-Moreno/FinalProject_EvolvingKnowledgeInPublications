from __future__ import annotations

from typing import Dict, Hashable, List, Sequence, Tuple

import numpy as np
from scipy.optimize import linear_sum_assignment


ClusterId = Hashable


def build_cost_matrix(similarity_matrix: np.ndarray) -> np.ndarray:
    """
    Convert a similarity matrix into a cost matrix for Hungarian matching.

    Since the Hungarian algorithm minimizes total cost, and we want to maximize
    similarity, we define:

        cost = 1 - similarity

    Parameters
    ----------
    similarity_matrix : np.ndarray
        Matrix of similarities in [0, 1].

    Returns
    -------
    np.ndarray
        Cost matrix of the same shape.

    Raises
    ------
    ValueError
        If the input is not a 2D array.
    """
    similarity_matrix = np.asarray(similarity_matrix, dtype=float)

    if similarity_matrix.ndim != 2:
        raise ValueError(
            f"similarity_matrix must be 2D, got shape {similarity_matrix.shape}."
        )

    return 1.0 - similarity_matrix


def hungarian_match_clusters(
    similarity_matrix: np.ndarray,
    cluster_ids_a: Sequence[ClusterId],
    cluster_ids_b: Sequence[ClusterId],
) -> Tuple[Dict[ClusterId, ClusterId], List[Tuple[ClusterId, ClusterId, float]]]:
    """
    Match clusters between two clusterings using the Hungarian algorithm.

    Parameters
    ----------
    similarity_matrix : np.ndarray
        Similarity matrix where entry [i, j] is the similarity between
        cluster_ids_a[i] and cluster_ids_b[j].
    cluster_ids_a : Sequence[ClusterId]
        Row cluster IDs.
    cluster_ids_b : Sequence[ClusterId]
        Column cluster IDs.

    Returns
    -------
    Tuple[Dict[ClusterId, ClusterId], List[Tuple[ClusterId, ClusterId, float]]]
        matches_dict:
            Mapping from cluster in A -> matched cluster in B
        matches_list:
            List of tuples:
            (cluster_id_a, cluster_id_b, similarity_score)

    Raises
    ------
    ValueError
        If matrix dimensions do not match the given cluster ID lists.
    """
    similarity_matrix = np.asarray(similarity_matrix, dtype=float)

    if similarity_matrix.ndim != 2:
        raise ValueError(
            f"similarity_matrix must be 2D, got shape {similarity_matrix.shape}."
        )

    n_rows, n_cols = similarity_matrix.shape

    if n_rows != len(cluster_ids_a):
        raise ValueError(
            f"Row mismatch: matrix has {n_rows} rows but got {len(cluster_ids_a)} cluster_ids_a."
        )

    if n_cols != len(cluster_ids_b):
        raise ValueError(
            f"Column mismatch: matrix has {n_cols} columns but got {len(cluster_ids_b)} cluster_ids_b."
        )

    if n_rows == 0 or n_cols == 0:
        return {}, []

    cost_matrix = build_cost_matrix(similarity_matrix)
    row_ind, col_ind = linear_sum_assignment(cost_matrix)

    matches_dict: Dict[ClusterId, ClusterId] = {}
    matches_list: List[Tuple[ClusterId, ClusterId, float]] = []

    for i, j in zip(row_ind, col_ind):
        cluster_a = cluster_ids_a[i]
        cluster_b = cluster_ids_b[j]
        similarity = float(similarity_matrix[i, j])

        matches_dict[cluster_a] = cluster_b
        matches_list.append((cluster_a, cluster_b, similarity))

    return matches_dict, matches_list


def average_matched_similarity(
    matches_list: Sequence[Tuple[ClusterId, ClusterId, float]]
) -> float:
    """
    Compute the average similarity across matched cluster pairs.

    Parameters
    ----------
    matches_list : Sequence[Tuple[ClusterId, ClusterId, float]]
        Output produced by `hungarian_match_clusters`.

    Returns
    -------
    float
        Mean similarity of matched pairs. Returns 0.0 if there are no matches.
    """
    if not matches_list:
        return 0.0

    scores = [score for _, _, score in matches_list]
    return float(np.mean(scores))