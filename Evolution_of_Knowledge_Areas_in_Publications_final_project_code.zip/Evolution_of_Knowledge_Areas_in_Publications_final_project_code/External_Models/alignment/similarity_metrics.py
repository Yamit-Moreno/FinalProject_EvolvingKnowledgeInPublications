from __future__ import annotations

from typing import Dict, Hashable, List, Sequence, Set, Tuple

import numpy as np


NodeId = Hashable
ClusterId = Hashable


def jaccard_similarity(set_a: Set[NodeId], set_b: Set[NodeId]) -> float:
    """
    Compute Jaccard similarity between two sets.

    J(A, B) = |A ∩ B| / |A ∪ B|
    """
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0

    intersection_size = len(set_a & set_b)
    union_size = len(set_a | set_b)

    if union_size == 0:
        return 1.0

    return intersection_size / union_size


def labels_to_clusters(
    node_ids: Sequence[NodeId],
    labels: Sequence[ClusterId],
) -> Dict[ClusterId, Set[NodeId]]:
    """
    Convert parallel lists of node IDs and cluster labels into:
    cluster_id -> set(node_ids)
    """
    if len(node_ids) != len(labels):
        raise ValueError(
            f"Length mismatch: got {len(node_ids)} node_ids and {len(labels)} labels."
        )

    clusters: Dict[ClusterId, Set[NodeId]] = {}
    for node_id, label in zip(node_ids, labels):
        clusters.setdefault(label, set()).add(node_id)

    return clusters


def cluster_jaccard_matrix(
    clusters_a: Dict[ClusterId, Set[NodeId]],
    clusters_b: Dict[ClusterId, Set[NodeId]],
) -> Tuple[np.ndarray, List[ClusterId], List[ClusterId]]:
    """
    Build a Jaccard similarity matrix between two clusterings.
    """
    cluster_ids_a = list(clusters_a.keys())
    cluster_ids_b = list(clusters_b.keys())

    similarity_matrix = np.zeros((len(cluster_ids_a), len(cluster_ids_b)), dtype=float)

    for i, cluster_id_a in enumerate(cluster_ids_a):
        for j, cluster_id_b in enumerate(cluster_ids_b):
            similarity_matrix[i, j] = jaccard_similarity(
                clusters_a[cluster_id_a],
                clusters_b[cluster_id_b],
            )

    return similarity_matrix, cluster_ids_a, cluster_ids_b


def cluster_jaccard_matrix_from_labels(
    node_ids_a: Sequence[NodeId],
    labels_a: Sequence[ClusterId],
    node_ids_b: Sequence[NodeId],
    labels_b: Sequence[ClusterId],
) -> Tuple[np.ndarray, List[ClusterId], List[ClusterId]]:
    """
    Build a Jaccard similarity matrix directly from node IDs and labels.
    """
    clusters_a = labels_to_clusters(node_ids_a, labels_a)
    clusters_b = labels_to_clusters(node_ids_b, labels_b)

    return cluster_jaccard_matrix(clusters_a, clusters_b)