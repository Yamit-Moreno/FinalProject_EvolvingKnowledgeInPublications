from External_Models.data.loader import load_raw_data


def build_clean_graph_tables(data_path=None):
    """
    Build clean graph tables from the raw JSONL data.

    Returns:
    1. papers_clean_df:
       paper_id, year, fos_name

    2. edges_clean_df:
       source, target
       Only edges where both source and target exist in papers_df.

    3. stats:
       Dictionary with basic graph statistics.
    """

    papers_df, edges_df = load_raw_data(data_path=data_path)

    # Ensure IDs are strings
    papers_df = papers_df.copy()
    edges_df = edges_df.copy()

    papers_df["paper_id"] = papers_df["paper_id"].astype(str)

    if not edges_df.empty:
        edges_df["source"] = edges_df["source"].astype(str)
        edges_df["target"] = edges_df["target"].astype(str)

    all_paper_ids = set(papers_df["paper_id"])

    original_edges_count = len(edges_df)

    # Keep only citation edges where both source and target are inside the dataset
    if edges_df.empty:
        edges_clean_df = edges_df.copy()
    else:
        edges_clean_df = edges_df[
            edges_df["source"].isin(all_paper_ids)
            & edges_df["target"].isin(all_paper_ids)
            & (edges_df["source"] != edges_df["target"])
        ].copy()

    # Keep only papers that participate in at least one valid edge
    if edges_clean_df.empty:
        papers_clean_df = papers_df.copy()
    else:
        connected_ids = set(edges_clean_df["source"]) | set(edges_clean_df["target"])
        papers_clean_df = papers_df[papers_df["paper_id"].isin(connected_ids)].copy()

    stats = {
        "original_papers": len(papers_df),
        "original_edges": original_edges_count,
        "clean_papers": len(papers_clean_df),
        "clean_edges": len(edges_clean_df),
        "removed_edges": original_edges_count - len(edges_clean_df),
        "min_year": int(papers_clean_df["year"].min()) if not papers_clean_df.empty else None,
        "max_year": int(papers_clean_df["year"].max()) if not papers_clean_df.empty else None,
        "num_fos": int(papers_clean_df["fos_name"].nunique()) if not papers_clean_df.empty else 0,
    }

    return papers_clean_df, edges_clean_df, stats