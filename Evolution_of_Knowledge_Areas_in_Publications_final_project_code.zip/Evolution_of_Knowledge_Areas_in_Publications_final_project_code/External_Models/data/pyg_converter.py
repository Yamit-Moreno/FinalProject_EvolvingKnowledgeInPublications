import torch


def convert_snapshot_to_pyg(features_df, edges_df):
    """
    Convert snapshot tables into PyTorch Geometric format.

    Input:
    - features_df:
        paper_id, year, fos_name, feature columns...
    - edges_df:
        source, target

    Output:
    - x:
        torch tensor of node features, shape [num_nodes, num_features]
    - edge_index:
        torch tensor of edges, shape [2, num_edges]
    - node_index_map:
        dictionary mapping paper_id -> node index
    """

    if features_df.empty:
        raise ValueError("features_df is empty. Cannot convert empty snapshot to PyG format.")

    # Make sure paper ids are strings
    features_df = features_df.copy()
    features_df["paper_id"] = features_df["paper_id"].astype(str)

    # Feature columns are all columns except metadata columns
    metadata_columns = ["paper_id", "year", "fos_name"]
    feature_columns = [
        col for col in features_df.columns
        if col not in metadata_columns
    ]

    if len(feature_columns) == 0:
        raise ValueError("No feature columns found in features_df.")

    # Create node index mapping: real paper_id -> internal index 0,1,2,...
    node_ids = features_df["paper_id"].tolist()
    node_index_map = {
        paper_id: index
        for index, paper_id in enumerate(node_ids)
    }

    # Create x tensor: node feature matrix
    x_values = features_df[feature_columns].astype(float).values
    x = torch.tensor(x_values, dtype=torch.float)

    # Convert edges from paper ids to node indices
    edge_pairs = []

    if edges_df is not None and not edges_df.empty:
        edges_df = edges_df.copy()
        edges_df["source"] = edges_df["source"].astype(str)
        edges_df["target"] = edges_df["target"].astype(str)

        for _, row in edges_df.iterrows():
            source = row["source"]
            target = row["target"]

            if source in node_index_map and target in node_index_map:
                source_idx = node_index_map[source]
                target_idx = node_index_map[target]
                edge_pairs.append([source_idx, target_idx])

    # If there are no edges, return an empty edge_index with correct shape
    if len(edge_pairs) == 0:
        edge_index = torch.empty((2, 0), dtype=torch.long)
    else:
        edge_index = torch.tensor(edge_pairs, dtype=torch.long).t().contiguous()

    return x, edge_index, node_index_map