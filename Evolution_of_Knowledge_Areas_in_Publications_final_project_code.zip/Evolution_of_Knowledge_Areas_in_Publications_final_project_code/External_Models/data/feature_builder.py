import pandas as pd


def build_node_features(papers_df, edges_df=None):
    """
    Build node feature table from snapshot papers.

    Input:
    - papers_df: DataFrame with columns:
        paper_id, year, fos_name

    Output:
    - features_df:
        paper_id, year, fos_name, plus one-hot columns for each fos_name
    """

    if papers_df.empty:
        return pd.DataFrame(columns=["paper_id", "year", "fos_name"])

    features_df = papers_df.copy()

    features_df["paper_id"] = features_df["paper_id"].astype(str)
    features_df["year"] = features_df["year"].astype(int)

    # Fill missing FOS with Unknown
    features_df["fos_name"] = features_df["fos_name"].fillna("Unknown").astype(str)

    # One-hot encoding for FOS categories
    fos_one_hot = pd.get_dummies(features_df["fos_name"], prefix="fos").astype(float)

    features_df = pd.concat(
        [
            features_df[["paper_id", "year", "fos_name"]].reset_index(drop=True),
            fos_one_hot.reset_index(drop=True)
        ],
        axis=1
    )

    return features_df


def summarize_feature_table(features_df):
    """
    Return summary statistics for the feature table.
    """

    if features_df.empty:
        return {
            "num_nodes": 0,
            "num_feature_columns": 0,
            "feature_columns": [],
            "num_fos": 0,
            "fos_counts": {}
        }

    feature_columns = [
        col for col in features_df.columns
        if col not in ["paper_id", "year", "fos_name"]
    ]

    summary = {
        "num_nodes": len(features_df),
        "num_feature_columns": len(feature_columns),
        "feature_columns": feature_columns,
        "num_fos": features_df["fos_name"].nunique(),
        "fos_counts": features_df["fos_name"].value_counts().to_dict()
    }

    return summary