from External_Models.data.graph_builder import build_clean_graph_tables


def get_available_years(data_path=None):
    """
    Return sorted list of available years in the clean graph.
    """
    papers_df, edges_df, stats = build_clean_graph_tables(data_path=data_path)
    return sorted(papers_df["year"].dropna().astype(int).unique().tolist())


def build_year_window_snapshot(start_year, end_year, data_path=None):
    """
    Build a cumulative citation graph snapshot.

    Cumulative meaning:
    - includes papers from start_year up to end_year
    - includes only valid edges where both source and target papers are inside the snapshot

    Example:
    build_year_window_snapshot(2000, 2010)
    returns all papers from 2000 to 2010 and citations between them.
    """

    papers_df, edges_df, _ = build_clean_graph_tables(data_path=data_path)

    start_year = int(start_year)
    end_year = int(end_year)

    # cumulative snapshot: all papers between start_year and end_year
    snapshot_papers_df = papers_df[
        (papers_df["year"] >= start_year) &
        (papers_df["year"] <= end_year)
    ].copy()

    snapshot_ids = set(snapshot_papers_df["paper_id"].astype(str))

    if edges_df.empty:
        snapshot_edges_df = edges_df.copy()
    else:
        snapshot_edges_df = edges_df[
            edges_df["source"].astype(str).isin(snapshot_ids) &
            edges_df["target"].astype(str).isin(snapshot_ids)
        ].copy()

    stats = {
        "start_year": start_year,
        "end_year": end_year,
        "num_papers": len(snapshot_papers_df),
        "num_edges": len(snapshot_edges_df),
        "min_year": int(snapshot_papers_df["year"].min()) if not snapshot_papers_df.empty else None,
        "max_year": int(snapshot_papers_df["year"].max()) if not snapshot_papers_df.empty else None,
        "num_fos": int(snapshot_papers_df["fos_name"].nunique()) if not snapshot_papers_df.empty else 0,
    }

    return snapshot_papers_df, snapshot_edges_df, stats