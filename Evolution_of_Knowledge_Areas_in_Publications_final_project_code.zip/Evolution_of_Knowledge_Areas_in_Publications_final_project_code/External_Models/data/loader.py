import json
from pathlib import Path

import pandas as pd


def load_raw_data(data_path=None):
    """
    Load citation data from JSONL file and return:
    1. papers_df: paper_id, year, fos_name
    2. edges_df: source, target
    """

    if data_path is None:
        data_path = Path(__file__).parent / "data_processed.jsonl"
    else:
        data_path = Path(data_path)

    if not data_path.exists():
        raise FileNotFoundError(f"Data file not found: {data_path}")

    papers = []
    edges = []

    with open(data_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue

            record = json.loads(line)

            paper_id = str(record.get("id"))
            year = record.get("year")
            references = record.get("references", [])
            fos = record.get("fos", [])

            if not paper_id or year is None:
                continue

            fos_name = None
            if isinstance(fos, list) and len(fos) > 0 and isinstance(fos[0], dict):
                fos_name = fos[0].get("name")

            papers.append({
                "paper_id": paper_id,
                "year": int(year),
                "fos_name": fos_name
            })

            if isinstance(references, list):
                for ref in references:
                    edges.append({
                        "source": paper_id,
                        "target": str(ref)
                    })

    papers_df = pd.DataFrame(papers)
    edges_df = pd.DataFrame(edges)

    return papers_df, edges_df