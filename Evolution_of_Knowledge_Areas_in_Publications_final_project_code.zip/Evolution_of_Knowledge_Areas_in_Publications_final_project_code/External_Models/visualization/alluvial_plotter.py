from __future__ import annotations

from collections import Counter
from typing import Dict, List, Sequence, Tuple

import plotly.graph_objects as go
import pandas as pd


def _build_cluster_name(snapshot_idx: int, cluster_id: int) -> str:
    """
    Build a readable cluster node name for visualization.
    """
    return f"T{snapshot_idx}_C{cluster_id}"


def _build_label_map(features_df: pd.DataFrame, labels: Sequence[int]) -> Dict[str, int]:
    """
    Build mapping: paper_id -> cluster label.
    """
    paper_ids = features_df["paper_id"].astype(str).tolist()

    if len(paper_ids) != len(labels):
        raise ValueError(
            f"Length mismatch: got {len(paper_ids)} paper IDs and {len(labels)} labels."
        )

    return {paper_id: int(label) for paper_id, label in zip(paper_ids, labels)}


def build_alluvial_nodes_from_windows(
    windows: Sequence[Dict[str, object]],
) -> Tuple[List[Dict[str, object]], Dict[Tuple[int, int], int]]:
    """
    Build Sankey nodes from window clustering results.

    Each window dictionary must contain:
    - 'features_df'
    - 'labels'
    """
    nodes: List[Dict[str, object]] = []
    node_index_map: Dict[Tuple[int, int], int] = {}

    for snapshot_idx, window in enumerate(windows):
        features_df = window["features_df"]
        labels = window["labels"]

        cluster_counts = Counter(labels)

        for cluster_id in sorted(cluster_counts.keys()):
            node_idx = len(nodes)
            node_index_map[(snapshot_idx, int(cluster_id))] = node_idx

            nodes.append(
                {
                    "id": node_idx,
                    "label": _build_cluster_name(snapshot_idx, int(cluster_id)),
                    "snapshot": snapshot_idx,
                    "cluster_id": int(cluster_id),
                    "size": int(cluster_counts[cluster_id]),
                }
            )

    return nodes, node_index_map


def build_alluvial_links_from_windows(
    windows: Sequence[Dict[str, object]],
    node_index_map: Dict[Tuple[int, int], int],
) -> List[Dict[str, int]]:
    """
    Build Sankey links using common paper IDs between consecutive windows.
    """
    links: List[Dict[str, int]] = []

    for snapshot_idx in range(len(windows) - 1):
        window_a = windows[snapshot_idx]
        window_b = windows[snapshot_idx + 1]

        features_df_a = window_a["features_df"]
        labels_a = window_a["labels"]

        features_df_b = window_b["features_df"]
        labels_b = window_b["labels"]

        label_map_a = _build_label_map(features_df_a, labels_a)
        label_map_b = _build_label_map(features_df_b, labels_b)

        common_ids = sorted(set(label_map_a.keys()) & set(label_map_b.keys()))

        flow_counter: Dict[Tuple[int, int], int] = {}

        for paper_id in common_ids:
            cluster_a = label_map_a[paper_id]
            cluster_b = label_map_b[paper_id]
            key = (cluster_a, cluster_b)
            flow_counter[key] = flow_counter.get(key, 0) + 1

        for (cluster_a, cluster_b), value in sorted(flow_counter.items()):
            source = node_index_map[(snapshot_idx, cluster_a)]
            target = node_index_map[(snapshot_idx + 1, cluster_b)]

            links.append(
                {
                    "source": source,
                    "target": target,
                    "value": int(value),
                }
            )

    return links


def prepare_alluvial_data_from_windows(
    windows: Sequence[Dict[str, object]],
) -> Dict[str, object]:
    """
    Prepare nodes and links for alluvial/Sankey visualization from window results.
    """
    if len(windows) < 2:
        raise ValueError("At least 2 windows are required for alluvial visualization.")

    nodes, node_index_map = build_alluvial_nodes_from_windows(windows)
    links = build_alluvial_links_from_windows(windows, node_index_map)

    node_labels = [node["label"] for node in nodes]
    sources = [link["source"] for link in links]
    targets = [link["target"] for link in links]
    values = [link["value"] for link in links]

    return {
        "nodes": nodes,
        "links": links,
        "node_labels": node_labels,
        "sources": sources,
        "targets": targets,
        "values": values,
    }


def plot_alluvial_from_windows(
    windows: Sequence[Dict[str, object]],
    title: str = "Temporal Community Evolution",
):
    """
    Plot a Sankey-based alluvial diagram from temporal window results.

    Each window dictionary must contain:
    - 'features_df'
    - 'labels'
    """
    alluvial_data = prepare_alluvial_data_from_windows(windows)

    fig = go.Figure(
        data=[
            go.Sankey(
                node=dict(
                    pad=20,
                    thickness=20,
                    label=alluvial_data["node_labels"],
                ),
                link=dict(
                    source=alluvial_data["sources"],
                    target=alluvial_data["targets"],
                    value=alluvial_data["values"],
                ),
            )
        ]
    )

    fig.update_layout(
        title_text=title,
        font_size=12,
    )

    return fig