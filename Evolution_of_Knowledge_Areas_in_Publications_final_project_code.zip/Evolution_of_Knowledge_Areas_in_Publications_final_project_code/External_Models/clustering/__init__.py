
import numpy as np
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import silhouette_score

def run_clustering(embedding_vectors, n_clusters):
    if n_clusters < 2: n_clusters = 2
    kmeans = MiniBatchKMeans(n_clusters=n_clusters, random_state=42, batch_size=1024, n_init=3)
    labels = kmeans.fit_predict(embedding_vectors)
    try:
        score = silhouette_score(embedding_vectors, labels, sample_size=10000)
    except:
        score = 0
    return labels, score
