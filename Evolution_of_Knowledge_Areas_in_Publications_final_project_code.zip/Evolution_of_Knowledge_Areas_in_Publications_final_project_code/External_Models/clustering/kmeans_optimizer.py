from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import silhouette_score


def _validate_embeddings(embedding_vectors: np.ndarray) -> np.ndarray:
    """
    Validate and normalize embedding input into a 2D numpy array.
    """
    embedding_vectors = np.asarray(embedding_vectors, dtype=float)

    if embedding_vectors.ndim != 2:
        raise ValueError(
            f"embedding_vectors must be a 2D array, got shape {embedding_vectors.shape}."
        )

    n_samples, n_features = embedding_vectors.shape

    if n_samples < 2:
        raise ValueError("At least 2 samples are required for clustering.")

    if n_features < 1:
        raise ValueError("Embeddings must contain at least 1 feature.")

    return embedding_vectors


def run_clustering(
    embedding_vectors: np.ndarray,
    n_clusters: int,
    random_state: int = 42,
    batch_size: int = 1024,
    n_init: int = 10,
) -> Tuple[np.ndarray, float]:
    """
    Run MiniBatchKMeans clustering and compute silhouette score.

    Parameters
    ----------
    embedding_vectors : np.ndarray
        Node embedding matrix of shape (n_samples, n_features).
    n_clusters : int
        Number of clusters to fit.
    random_state : int, default=42
        Random seed for reproducibility.
    batch_size : int, default=1024
        Batch size for MiniBatchKMeans.
    n_init : int, default=10
        Number of initializations for clustering.

    Returns
    -------
    Tuple[np.ndarray, float]
        labels : np.ndarray
            Cluster label for each sample.
        score : float
            Silhouette score. Returns -1.0 if score cannot be computed.
    """
    embedding_vectors = _validate_embeddings(embedding_vectors)

    n_samples = embedding_vectors.shape[0]

    if n_clusters < 2:
        raise ValueError("n_clusters must be at least 2.")

    if n_clusters > n_samples:
        raise ValueError(
            f"n_clusters ({n_clusters}) cannot exceed number of samples ({n_samples})."
        )

    kmeans = MiniBatchKMeans(
        n_clusters=n_clusters,
        random_state=random_state,
        batch_size=batch_size,
        n_init=n_init,
    )

    labels = kmeans.fit_predict(embedding_vectors)

    unique_labels = np.unique(labels)
    if len(unique_labels) < 2:
        return labels, -1.0

    try:
        if n_samples > 10000:
            score = silhouette_score(
                embedding_vectors,
                labels,
                sample_size=10000,
                random_state=random_state,
            )
        else:
            score = silhouette_score(embedding_vectors, labels)
    except ValueError:
        score = -1.0

    return labels, float(score)


def find_best_k(
    embedding_vectors: np.ndarray,
    k_min: int = 2,
    k_max: int = 10,
    random_state: int = 42,
    batch_size: int = 1024,
    n_init: int = 10,
) -> Tuple[int, np.ndarray, float, Dict[int, float]]:
    """
    Search for the best K using silhouette score.

    Parameters
    ----------
    embedding_vectors : np.ndarray
        Node embedding matrix of shape (n_samples, n_features).
    k_min : int, default=2
        Minimum number of clusters to test.
    k_max : int, default=10
        Maximum number of clusters to test.
    random_state : int, default=42
        Random seed for reproducibility.
    batch_size : int, default=1024
        Batch size for MiniBatchKMeans.
    n_init : int, default=10
        Number of initializations for clustering.

    Returns
    -------
    Tuple[int, np.ndarray, float, Dict[int, float]]
        best_k : int
            Best number of clusters.
        best_labels : np.ndarray
            Labels for the best clustering.
        best_score : float
            Best silhouette score.
        scores_by_k : Dict[int, float]
            Mapping from K to silhouette score.
    """
    embedding_vectors = _validate_embeddings(embedding_vectors)
    n_samples = embedding_vectors.shape[0]

    if k_min < 2:
        k_min = 2

    k_max = min(k_max, n_samples)

    if k_min > k_max:
        raise ValueError(
            f"Invalid K range after adjustment: k_min={k_min}, k_max={k_max}."
        )

    best_k: Optional[int] = None
    best_labels: Optional[np.ndarray] = None
    best_score = float("-inf")
    scores_by_k: Dict[int, float] = {}

    for k in range(k_min, k_max + 1):
        labels, score = run_clustering(
            embedding_vectors=embedding_vectors,
            n_clusters=k,
            random_state=random_state,
            batch_size=batch_size,
            n_init=n_init,
        )

        scores_by_k[k] = score

        if score > best_score:
            best_k = k
            best_labels = labels
            best_score = score

    if best_k is None or best_labels is None:
        raise RuntimeError("Failed to find a valid clustering solution.")

    return best_k, best_labels, float(best_score), scores_by_k
