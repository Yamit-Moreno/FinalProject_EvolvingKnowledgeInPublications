from __future__ import annotations

from itertools import combinations
from typing import Dict, List, Sequence, Tuple

import numpy as np

from External_Models.alignment.hungarian_matcher import (
    average_matched_similarity,
    hungarian_match_clusters,
)
from External_Models.alignment.similarity_metrics import (
    cluster_jaccard_matrix_from_labels,
)
from External_Models.clustering.kmeans_optimizer import run_clustering


def generate_seed_list(
    num_runs: int,
    base_seed: int = 42,
) -> List[int]:
    """
    Generate a deterministic list of random seeds.

    Parameters
    ----------
    num_runs : int
        Number of clustering runs.
    base_seed : int, default=42
        Starting seed.

    Returns
    -------
    List[int]
        List of seeds to use across runs.
    """
    if num_runs < 2:
        raise ValueError("num_runs must be at least 2.")

    return [base_seed + i for i in range(num_runs)]


def run_multiple_clusterings(
    embedding_vectors: np.ndarray,
    n_clusters: int,
    num_runs: int = 5,
    base_seed: int = 42,
    batch_size: int = 1024,
    n_init: int = 10,
) -> List[Dict[str, object]]:
    """
    Run clustering multiple times using different random seeds.

    Parameters
    ----------
    embedding_vectors : np.ndarray
        Embedding matrix of shape (n_samples, n_features).
    n_clusters : int
        Number of clusters.
    num_runs : int, default=5
        Number of repeated runs.
    base_seed : int, default=42
        Starting seed value.
    batch_size : int, default=1024
        MiniBatchKMeans batch size.
    n_init : int, default=10
        Number of initializations for KMeans.

    Returns
    -------
    List[Dict[str, object]]
        Each item contains:
        - 'seed': int
        - 'labels': np.ndarray
        - 'score': float
    """
    seeds = generate_seed_list(num_runs=num_runs, base_seed=base_seed)
    results: List[Dict[str, object]] = []

    for seed in seeds:
        labels, score = run_clustering(
            embedding_vectors=embedding_vectors,
            n_clusters=n_clusters,
            random_state=seed,
            batch_size=batch_size,
            n_init=n_init,
        )

        results.append(
            {
                "seed": seed,
                "labels": labels,
                "score": score,
            }
        )

    return results


def compare_two_cluster_runs(
    node_ids: Sequence[int],
    labels_a: Sequence[int],
    labels_b: Sequence[int],
) -> Dict[str, object]:
    """
    Compare two clustering runs using Jaccard similarity + Hungarian matching.

    Parameters
    ----------
    node_ids : Sequence[int]
        Node IDs shared by both runs, in the same order as labels_a and labels_b.
    labels_a : Sequence[int]
        Labels from run A.
    labels_b : Sequence[int]
        Labels from run B.

    Returns
    -------
    Dict[str, object]
        Contains:
        - 'similarity_matrix'
        - 'cluster_ids_a'
        - 'cluster_ids_b'
        - 'matches_dict'
        - 'matches_list'
        - 'average_similarity'
    """
    similarity_matrix, cluster_ids_a, cluster_ids_b = cluster_jaccard_matrix_from_labels(
        node_ids_a=node_ids,
        labels_a=labels_a,
        node_ids_b=node_ids,
        labels_b=labels_b,
    )

    matches_dict, matches_list = hungarian_match_clusters(
        similarity_matrix=similarity_matrix,
        cluster_ids_a=cluster_ids_a,
        cluster_ids_b=cluster_ids_b,
    )

    avg_similarity = average_matched_similarity(matches_list)

    return {
        "similarity_matrix": similarity_matrix,
        "cluster_ids_a": cluster_ids_a,
        "cluster_ids_b": cluster_ids_b,
        "matches_dict": matches_dict,
        "matches_list": matches_list,
        "average_similarity": avg_similarity,
    }


def compute_jaccard_robustness(
    embedding_vectors: np.ndarray,
    n_clusters: int,
    num_runs: int = 5,
    base_seed: int = 42,
    batch_size: int = 1024,
    n_init: int = 10,
) -> Dict[str, object]:
    """
    Compute clustering robustness across multiple runs.

    The method:
    1. Runs KMeans multiple times with different seeds.
    2. Compares every pair of runs.
    3. Uses Jaccard + Hungarian matching for cluster alignment.
    4. Returns the average matched similarity across run pairs.

    Parameters
    ----------
    embedding_vectors : np.ndarray
        Embedding matrix of shape (n_samples, n_features).
    n_clusters : int
        Number of clusters.
    num_runs : int, default=5
        Number of repeated runs.
    base_seed : int, default=42
        Starting seed value.
    batch_size : int, default=1024
        MiniBatchKMeans batch size.
    n_init : int, default=10
        Number of initializations for KMeans.

    Returns
    -------
    Dict[str, object]
        Contains:
        - 'runs': list of clustering results
        - 'pairwise_scores': list of pairwise comparison summaries
        - 'mean_robustness': float
        - 'std_robustness': float
    """
    embedding_vectors = np.asarray(embedding_vectors, dtype=float)
    n_samples = embedding_vectors.shape[0]
    node_ids = list(range(n_samples))

    runs = run_multiple_clusterings(
        embedding_vectors=embedding_vectors,
        n_clusters=n_clusters,
        num_runs=num_runs,
        base_seed=base_seed,
        batch_size=batch_size,
        n_init=n_init,
    )

    pairwise_scores: List[Dict[str, object]] = []

    for run_a, run_b in combinations(runs, 2):
        comparison = compare_two_cluster_runs(
            node_ids=node_ids,
            labels_a=run_a["labels"],
            labels_b=run_b["labels"],
        )

        pairwise_scores.append(
            {
                "seed_a": run_a["seed"],
                "seed_b": run_b["seed"],
                "score_a": run_a["score"],
                "score_b": run_b["score"],
                "average_similarity": comparison["average_similarity"],
                "matches_list": comparison["matches_list"],
            }
        )

    if pairwise_scores:
        robustness_values = [item["average_similarity"] for item in pairwise_scores]
        mean_robustness = float(np.mean(robustness_values))
        std_robustness = float(np.std(robustness_values))
    else:
        mean_robustness = 0.0
        std_robustness = 0.0

    return {
        "runs": runs,
        "pairwise_scores": pairwise_scores,
        "mean_robustness": mean_robustness,
        "std_robustness": std_robustness,
    }