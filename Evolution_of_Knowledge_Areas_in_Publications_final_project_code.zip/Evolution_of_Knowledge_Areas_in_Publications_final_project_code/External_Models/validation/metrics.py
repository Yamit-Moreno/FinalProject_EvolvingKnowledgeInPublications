from __future__ import annotations

from collections import Counter
from typing import Dict, Sequence

import numpy as np
from sklearn.metrics import silhouette_score


def compute_silhouette_metric(
    embedding_vectors: np.ndarray,
    labels: Sequence[int],
    sample_size: int | None = 10000,
) -> float:
    """
    Compute silhouette score for a clustering result.

    Parameters
    ----------
    embedding_vectors : np.ndarray
        Embedding matrix of shape (n_samples, n_features).
    labels : Sequence[int]
        Cluster label for each sample.
    sample_size : int | None, default=10000
        If the dataset is larger than this value, silhouette will be computed
        on a sample of this size. If None, uses the full dataset.

    Returns
    -------
    float
        Silhouette score. Returns -1.0 when the score cannot be computed.
    """
    embedding_vectors = np.asarray(embedding_vectors, dtype=float)
    labels = np.asarray(labels)

    if embedding_vectors.ndim != 2:
        raise ValueError(
            f"embedding_vectors must be 2D, got shape {embedding_vectors.shape}."
        )

    if len(embedding_vectors) != len(labels):
        raise ValueError(
            f"Length mismatch: got {len(embedding_vectors)} samples and {len(labels)} labels."
        )

    unique_labels = np.unique(labels)
    if len(unique_labels) < 2:
        return -1.0

    try:
        if sample_size is not None and len(embedding_vectors) > sample_size:
            score = silhouette_score(
                embedding_vectors,
                labels,
                sample_size=sample_size,
                random_state=42,
            )
        else:
            score = silhouette_score(embedding_vectors, labels)
    except ValueError:
        return -1.0

    return float(score)


def compute_cluster_size_distribution(labels: Sequence[int]) -> Dict[int, int]:
    """
    Count how many samples belong to each cluster.

    Parameters
    ----------
    labels : Sequence[int]
        Cluster labels.

    Returns
    -------
    Dict[int, int]
        Mapping: cluster_id -> cluster_size
    """
    counts = Counter(labels)
    return dict(sorted(counts.items(), key=lambda item: item[0]))


def compute_num_clusters(labels: Sequence[int]) -> int:
    """
    Compute the number of unique clusters.

    Parameters
    ----------
    labels : Sequence[int]
        Cluster labels.

    Returns
    -------
    int
        Number of unique clusters.
    """
    return int(len(set(labels)))


def summarize_clustering(
    embedding_vectors: np.ndarray,
    labels: Sequence[int],
) -> Dict[str, object]:
    """
    Build a compact summary of a clustering result.

    Parameters
    ----------
    embedding_vectors : np.ndarray
        Embedding matrix of shape (n_samples, n_features).
    labels : Sequence[int]
        Cluster labels.

    Returns
    -------
    Dict[str, object]
        Summary containing:
        - num_samples
        - num_clusters
        - silhouette_score
        - cluster_size_distribution
    """
    embedding_vectors = np.asarray(embedding_vectors, dtype=float)
    labels = np.asarray(labels)

    summary = {
        "num_samples": int(len(labels)),
        "num_clusters": compute_num_clusters(labels),
        "silhouette_score": compute_silhouette_metric(embedding_vectors, labels),
        "cluster_size_distribution": compute_cluster_size_distribution(labels),
    }

    return summary