from __future__ import annotations

from typing import Dict

import torch

from External_Models.clustering.kmeans_optimizer import find_best_k
from External_Models.clustering.robustness import compute_jaccard_robustness
from External_Models.data.feature_builder import build_node_features
from External_Models.data.pyg_converter import convert_snapshot_to_pyg
from External_Models.data.snapshot_builder import build_year_window_snapshot
from External_Models.embeddings.embedder import generate_embeddings
from External_Models.validation.metrics import summarize_clustering


def run_pipeline_smoke_test() -> Dict[str, object]:
    """
    Run a small end-to-end smoke test on a tiny synthetic graph.
    This checks that the core modules work technically.
    """
    x = torch.tensor([
        [1.0, 0.0, 0.5],
        [0.9, 0.1, 0.4],
        [0.0, 1.0, 0.6],
        [0.1, 0.9, 0.7],
        [0.5, 0.5, 0.5],
        [0.6, 0.4, 0.4],
    ], dtype=torch.float)

    edge_index = torch.tensor([
        [0, 1, 2, 3, 4, 5, 0, 2, 4],
        [1, 0, 3, 2, 5, 4, 4, 5, 0],
    ], dtype=torch.long)

    embeddings, embedding_info = generate_embeddings(
        x=x,
        edge_index=edge_index,
        hidden_channels=8,
        out_channels=4,
        epochs=30,
        verbose=False,
    )

    best_k, best_labels, best_score, scores_by_k = find_best_k(
        embedding_vectors=embeddings.numpy(),
        k_min=2,
        k_max=3,
    )

    clustering_summary = summarize_clustering(
        embedding_vectors=embeddings.numpy(),
        labels=best_labels,
    )

    robustness_result = compute_jaccard_robustness(
        embedding_vectors=embeddings.numpy(),
        n_clusters=best_k,
        num_runs=4,
        base_seed=42,
    )

    return {
        "test_type": "synthetic_small_graph",
        "embeddings_shape": tuple(embeddings.shape),
        "embedding_dim": embedding_info["embedding_dim"],
        "best_k": best_k,
        "best_score": best_score,
        "scores_by_k": scores_by_k,
        "clustering_summary": clustering_summary,
        "robustness_mean": robustness_result["mean_robustness"],
        "robustness_std": robustness_result["std_robustness"],
        "num_pairwise_comparisons": len(robustness_result["pairwise_scores"]),
    }


def run_real_data_pipeline_smoke_test(
    start_year: int = 2000,
    end_year: int = 2005,
    k_min: int = 2,
    k_max: int = 8,
    epochs: int = 30,
    robustness_runs: int = 4,
) -> Dict[str, object]:
    """
    Run an end-to-end smoke test on the real project dataset.

    Steps:
    1. Build cumulative snapshot.
    2. Build node features.
    3. Convert to PyTorch Geometric format.
    4. Generate GraphSAGE embeddings.
    5. Run KMeans and select best K.
    6. Summarize clustering.
    7. Compute robustness.
    """

    snapshot_papers_df, snapshot_edges_df, snapshot_stats = build_year_window_snapshot(
        start_year,
        end_year,
    )

    features_df = build_node_features(snapshot_papers_df, snapshot_edges_df)

    x, edge_index, node_index_map = convert_snapshot_to_pyg(
        features_df,
        snapshot_edges_df,
    )

    embeddings, embedding_info = generate_embeddings(
        x=x,
        edge_index=edge_index,
        hidden_channels=16,
        out_channels=8,
        epochs=epochs,
        verbose=False,
    )

    embeddings_np = embeddings.numpy()

    best_k, best_labels, best_score, scores_by_k = find_best_k(
        embedding_vectors=embeddings_np,
        k_min=k_min,
        k_max=k_max,
        random_state=42,
    )

    clustering_summary = summarize_clustering(
        embedding_vectors=embeddings_np,
        labels=best_labels,
    )

    robustness_result = compute_jaccard_robustness(
        embedding_vectors=embeddings_np,
        n_clusters=best_k,
        num_runs=robustness_runs,
        base_seed=42,
    )

    return {
        "test_type": "real_data_snapshot",
        "snapshot_stats": snapshot_stats,
        "features_shape": tuple(features_df.shape),
        "x_shape": tuple(x.shape),
        "edge_index_shape": tuple(edge_index.shape),
        "num_nodes_in_map": len(node_index_map),
        "embeddings_shape": tuple(embeddings.shape),
        "embedding_dim": embedding_info["embedding_dim"],
        "device": embedding_info["device"],
        "last_loss": embedding_info["history"]["loss"][-1],
        "best_k": best_k,
        "best_score": best_score,
        "scores_by_k": scores_by_k,
        "clustering_summary": clustering_summary,
        "robustness_mean": robustness_result["mean_robustness"],
        "robustness_std": robustness_result["std_robustness"],
        "num_pairwise_comparisons": len(robustness_result["pairwise_scores"]),
    }


if __name__ == "__main__":
    result = run_real_data_pipeline_smoke_test()

    print("Real data pipeline smoke test completed successfully.")
    for key, value in result.items():
        print(f"{key}: {value}")