from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
import torch.nn.functional as F
from torch import Tensor
from torch.optim import Adam

from External_Models.embeddings.graphsage_model import GraphSAGEModel


def _validate_graph_inputs(x: Tensor, edge_index: Tensor) -> Tuple[Tensor, Tensor]:
    if x.ndim != 2:
        raise ValueError(f"x must be 2D, got shape {tuple(x.shape)}")

    if edge_index.ndim != 2 or edge_index.shape[0] != 2:
        raise ValueError(
            f"edge_index must have shape [2, num_edges], got {tuple(edge_index.shape)}"
        )

    if x.shape[0] < 2:
        raise ValueError("At least 2 nodes are required.")

    if x.shape[1] < 1:
        raise ValueError("Node features must have at least 1 column.")

    if edge_index.shape[1] < 1:
        raise ValueError("At least 1 edge is required.")

    return x, edge_index


def _edge_reconstruction_loss(z: Tensor, edge_index: Tensor) -> Tensor:
    src, dst = edge_index
    scores = (z[src] * z[dst]).sum(dim=1)
    target = torch.ones_like(scores)
    return F.binary_cross_entropy_with_logits(scores, target)


def train_graphsage(
    x: Tensor,
    edge_index: Tensor,
    hidden_channels: int = 64,
    out_channels: int = 32,
    dropout: float = 0.3,
    learning_rate: float = 1e-3,
    weight_decay: float = 1e-4,
    epochs: int = 100,
    device: Optional[str] = None,
    verbose: bool = False,
) -> Tuple[GraphSAGEModel, Dict[str, list]]:
    x, edge_index = _validate_graph_inputs(x, edge_index)

    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    x = x.to(device)
    edge_index = edge_index.to(device)

    model = GraphSAGEModel(
        in_channels=x.shape[1],
        hidden_channels=hidden_channels,
        out_channels=out_channels,
        dropout=dropout,
    ).to(device)

    optimizer = Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay,
    )

    history = {"loss": []}

    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()

        z = model(x, edge_index)
        loss = _edge_reconstruction_loss(z, edge_index)

        loss.backward()
        optimizer.step()

        loss_value = float(loss.item())
        history["loss"].append(loss_value)

        if verbose and (epoch == 0 or (epoch + 1) % 10 == 0):
            print(f"Epoch {epoch + 1}/{epochs} - loss: {loss_value:.6f}")

    return model, history


def generate_embeddings(
    x: Tensor,
    edge_index: Tensor,
    hidden_channels: int = 64,
    out_channels: int = 32,
    dropout: float = 0.3,
    learning_rate: float = 1e-3,
    weight_decay: float = 1e-4,
    epochs: int = 100,
    device: Optional[str] = None,
    verbose: bool = False,
) -> Tuple[Tensor, Dict[str, object]]:
    model, history = train_graphsage(
        x=x,
        edge_index=edge_index,
        hidden_channels=hidden_channels,
        out_channels=out_channels,
        dropout=dropout,
        learning_rate=learning_rate,
        weight_decay=weight_decay,
        epochs=epochs,
        device=device,
        verbose=verbose,
    )

    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    model.eval()
    with torch.no_grad():
        embeddings = model.get_embeddings(
            x.to(device),
            edge_index.to(device),
        ).cpu()

    info = {
        "model": model,
        "history": history,
        "embedding_dim": out_channels,
        "device": device,
    }

    return embeddings, info