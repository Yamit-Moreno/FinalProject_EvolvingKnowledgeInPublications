from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import Tensor
from torch_geometric.nn import SAGEConv


class GraphSAGEModel(torch.nn.Module):
    """
    Two-layer GraphSAGE model for node embedding generation.

    Parameters
    ----------
    in_channels : int
        Number of input node features.
    hidden_channels : int
        Hidden layer dimensionality.
    out_channels : int
        Output embedding dimensionality.
    dropout : float, default=0.3
        Dropout probability applied after the first hidden layer.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        dropout: float = 0.3,
    ) -> None:
        super().__init__()

        if in_channels < 1:
            raise ValueError("in_channels must be at least 1.")
        if hidden_channels < 1:
            raise ValueError("hidden_channels must be at least 1.")
        if out_channels < 1:
            raise ValueError("out_channels must be at least 1.")
        if not (0.0 <= dropout < 1.0):
            raise ValueError("dropout must be in the range [0.0, 1.0).")

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.dropout = dropout

        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, out_channels)

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        """
        Forward pass of the GraphSAGE model.

        Parameters
        ----------
        x : Tensor
            Node feature matrix of shape [num_nodes, in_channels].
        edge_index : Tensor
            Graph connectivity in COO format with shape [2, num_edges].

        Returns
        -------
        Tensor
            Node embeddings of shape [num_nodes, out_channels].
        """
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.conv2(x, edge_index)
        return x

    @torch.no_grad()
    def get_embeddings(self, x: Tensor, edge_index: Tensor) -> Tensor:
        """
        Generate node embeddings in evaluation mode.

        Parameters
        ----------
        x : Tensor
            Node feature matrix.
        edge_index : Tensor
            Graph connectivity in COO format.

        Returns
        -------
        Tensor
            Output node embeddings.
        """
        was_training = self.training
        self.eval()
        embeddings = self.forward(x, edge_index)
        if was_training:
            self.train()
        return embeddings
